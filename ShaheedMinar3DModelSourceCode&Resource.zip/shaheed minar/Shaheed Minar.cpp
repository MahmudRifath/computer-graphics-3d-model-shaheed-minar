#include <iostream>
#include <stdlib.h>
#include<GL/gl.h>
#include <GL/glut.h>
#include<math.h>
#include<fstream>
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include<windows.h>
#include<mmsystem.h>
using namespace std;

///////////////////For loading texture //////////////////////
GLuint base_tex,tower_f;
GLUquadric *quad;


typedef uint16_t WORD;
typedef uint8_t BYTE;
int num_texture=-1;
int LoadTexture(char *filename, int width, int height)
{
    int i,j=0;
    FILE *l_file;
    unsigned char *l_texture;
    BITMAPFILEHEADER fileheader;
    BITMAPINFOHEADER infoheader;
    RGBTRIPLE rgb;

    num_texture++;
    if((l_file=fopen(filename,"rb"))==NULL)return(-1);

    infoheader.biWidth = width;
    infoheader.biHeight = height;

    l_texture=(unsigned char*)malloc(infoheader.biWidth*infoheader.biHeight*4);

    memset(l_texture,0,infoheader.biWidth * infoheader.biHeight*4);
    for(i=0;i<infoheader.biWidth*infoheader.biHeight;i++)
    {
        fread(&rgb,sizeof(rgb),1,l_file);
        l_texture[j+0]=rgb.rgbtRed;
        l_texture[j+1]=rgb.rgbtGreen;
        l_texture[j+2]=rgb.rgbtBlue;
        l_texture[j+3]=255;
        j+=4;
    }
    fclose(l_file);
    glBindTexture(GL_TEXTURE_2D,num_texture);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
    glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
    glTexImage2D(GL_TEXTURE_2D,0,4,infoheader.biWidth,infoheader.biHeight,0,GL_RGBA,GL_UNSIGNED_BYTE,l_texture);
    gluBuild2DMipmaps(GL_TEXTURE_2D,4,infoheader.biWidth,infoheader.biHeight,GL_RGBA,GL_UNSIGNED_BYTE,l_texture);
    free(l_texture);
    return(num_texture);
}
void FreeCreatedTexture(GLuint texture)
{
    glDeleteTextures(1, &texture);
}


GLuint textureStaircase,textureMeuseumImage[60],textureStick,textureInsideWall,textureRed,textureBrick,textureGrass,textureFloor,textureSky1,textureSky2,textureSky3,textureSky4,textureSky5,textureWall,textureCeiling2,textureWall1,textureCeiling,textureSky,maxresdefault;
GLuint textureTree,textureTreeBody,textureCloud,textureIntro,textureMusuem,textureFlower[2];


void func(){
 textureGrass = LoadTexture("grass.bmp",256,256);
 textureWall= LoadTexture("wall.bmp",256,256);
 textureWall1= LoadTexture("wall0.bmp",800,800);
 textureInsideWall= LoadTexture("insideWall.bmp",1600,1067);
 textureCeiling= LoadTexture("ceiling.bmp",864,576);
 textureCeiling2= LoadTexture("ceiling1.bmp",552,368);
 textureBrick= LoadTexture("brick.bmp",512,512);
 textureSky= LoadTexture("s.bmp",1024,1024);
 textureRed=LoadTexture("red.bmp",512,512);
 textureStick=LoadTexture("stick.bmp",512,512);
 textureStaircase=LoadTexture("shiri.bmp",256,256);
 textureFloor=LoadTexture("floor.bmp",1264,1264);
 textureMeuseumImage[1]=LoadTexture("1.bmp",512,408);
 textureMeuseumImage[0]=LoadTexture("0.bmp",256,256);
 textureMeuseumImage[2]=LoadTexture("2.bmp",512,370);
 textureMeuseumImage[3]=LoadTexture("3.bmp",512,342);
 textureMeuseumImage[4]=LoadTexture("4.bmp",512,540);
 textureMeuseumImage[5]=LoadTexture("5.bmp",512,512);
 textureMeuseumImage[6]=LoadTexture("6.bmp",512,437);
 textureMeuseumImage[7]=LoadTexture("7.bmp",512,397);
 textureMeuseumImage[8]=LoadTexture("8.bmp",512,342);
 textureMeuseumImage[9]=LoadTexture("9.bmp",512,342);
 textureMeuseumImage[10]=LoadTexture("10.bmp",512,341);
 textureMeuseumImage[11]=LoadTexture("11.bmp",512,318);
 textureMeuseumImage[12]=LoadTexture("12.bmp",512,347);
 textureMeuseumImage[13]=LoadTexture("13.bmp",512,359);
 textureMeuseumImage[14]=LoadTexture("14.bmp",512,417);
 textureMeuseumImage[15]=LoadTexture("15.bmp",512,478);
 textureMeuseumImage[16]=LoadTexture("16.bmp",512,397);
 textureMeuseumImage[17]=LoadTexture("17.bmp",512,408);
 textureMeuseumImage[18]=LoadTexture("18.bmp",512,325);
 textureMeuseumImage[19]=LoadTexture("19.bmp",512,406);
 textureMeuseumImage[20]=LoadTexture("20.bmp",512,501);
textureCloud=LoadTexture("cloud.bmp",128,128);

 textureTree=LoadTexture("tree.bmp",256,256);
 textureTreeBody=LoadTexture("treeb.bmp",256,256);
 textureIntro=LoadTexture("intro.bmp",480,480);
 textureMusuem=LoadTexture("musuem.bmp",480,480);
 //textureFlower[0]=LoadTexture("flower1.bmp",512,319);
 //textureFlower[1]=LoadTexture("flower.bmp",512,341);
 textureFlower[0]=LoadTexture("flower2.bmp",256,256);
 textureFlower[1]=LoadTexture("flower3.bmp",256,256);
}


// angle of rotation for the camera direction
float angle = 0.0f;
// vector representing the camera's direction
float lx=0.0f,lz=-1.0f;
// XZ position of the camera
//float x=-800.0f, z=300.0f;
float x=270.0f, z=900.0f;
float y=45.0f;
//initializations for movement and angle variables
////for camera movement speed
float deltaAngle = 0.0f;
//for moving speed
float deltaMove = 0.0f;
//for head up down angle speed
float Vangle=0.000f;
//cloud movement speed
float cloudS=0.0;
//updown movement speed
float upDown=0.0f;
//actual updown moved saved
float upangle=0.0f;

void changeSize(int w, int h) {

	// Prevent a divide by zero, when window is too short
	// (you cant make a window   of zero width).
	if (h == 0)
		h = 1;
	float ratio =  w * 1.0 / h;

	// Use the Projection Matrix
	glMatrixMode(GL_PROJECTION);

	// Reset Matrix
	glLoadIdentity();

	// Set the viewport to be the entire window
	glViewport(0, 0, w, h);

	// Set the correct perspective.
	gluPerspective(45.0f, ratio, 0.1f, 4000.0f);

	// Get Back to the Modelview
	glMatrixMode(GL_MODELVIEW);
}

void computePos(float deltaMove) {

    if(!(y<320 &&((x+deltaMove* lx+2)<-845 && (x+deltaMove* lx-2)>-870) && ((z+deltaMove* lz+10)<600 && (z+deltaMove* lz-5)>600-392))
        && !(y<300 &&((x+deltaMove* lx+2)<-845 && (x+deltaMove* lx-2)>-870) && ((z+deltaMove* lz+10)<30 && (z+deltaMove* lz-5)>-115))
        && !(y<300 &&((x+deltaMove* lx+2)<-845 && (x+deltaMove* lx-2)>-845-360) && ((z+deltaMove* lz+2)<-90 && (z+deltaMove* lz-2)>-115))
        && !(y<300 &&((x+deltaMove* lx+2)<-845 && (x+deltaMove* lx-2)>-845-360) && ((z+deltaMove* lz+2)<-85+700 && (z+deltaMove* lz-2)>-115+700))
        && !(y<300 &&((x+deltaMove* lx+2)<-1195 && (x+deltaMove* lx-2)>-1220) && ((z+deltaMove* lz+10)<600 && (z+deltaMove* lz-5)>-100)))
        {
            if((x+deltaMove* lx+10)<1500 && (x+deltaMove* lx-5)>-1500 && !(y<320 &&((x+deltaMove* lx+10)<450 && (x+deltaMove* lx-5)>-30) && ((z+deltaMove* lz+10)<10 && (z+deltaMove* lz-5)>-90)) )
            x += deltaMove * lx * 0.1f;
            if( (z+deltaMove* lz+10)<1500 && (z+deltaMove* lz-5)>-1500 && !(y<320 && ((x+deltaMove* lx+10)<450 && (x+deltaMove* lx-5)>-30) && ((z+deltaMove* lz+10)<10 && (z+deltaMove* lz-5)>-90)) )
            z += deltaMove * lz * 0.1f;

        }

  }
void computeUp(float upDown){
 if((y+upDown-5)>30.0 && (y+upDown+10)<1600.0)
  y+=upDown*0.1f;
  }

void computeUPangle(float ua){
    upangle+=ua;
}

void computeDir(float deltaAngle) {

	angle += deltaAngle;
	lx = sin(angle);
	lz = -cos(angle);
}

void stick(float h){
    glBegin(GL_QUADS);
		glTexCoord2f(0,0);glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);glVertex3f(3.0f, h, 0.0f);
		glTexCoord2f(0,1);glVertex3f( 0.0f, h, 0.0f);
    glEnd();
}
void wall(float h){
    glBindTexture(GL_TEXTURE_2D,textureWall);

    glPushMatrix();
    glBegin(GL_QUADS);
		glTexCoord2f(0,0);glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);glVertex3f(10.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);glVertex3f(10.0f, h, 0.0f);
		glTexCoord2f(0,1);glVertex3f( 0.0f, h, 0.0f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glRotatef(90,0,1,0);
    glBegin(GL_QUADS);
		glTexCoord2f(0,0);glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);glVertex3f(10.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);glVertex3f(10.0f, h, 0.0f);
		glTexCoord2f(0,1);glVertex3f( 0.0f, h, 0.0f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(10.0f,0,0);
    glRotatef(90,0,1,0);
    glBegin(GL_QUADS);
		glTexCoord2f(0,0);glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);glVertex3f(10.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);glVertex3f(10.0f, h, 0.0f);
		glTexCoord2f(0,1);glVertex3f( 0.0f, h, 0.0f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
           glTranslatef(0,0,-10.0f);
    glBegin(GL_QUADS);
		glTexCoord2f(0,0);glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);glVertex3f(10.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);glVertex3f(10.0f, h, 0.0f);
		glTexCoord2f(0,1);glVertex3f( 0.0f, h, 0.0f);
    glEnd();
    glPopMatrix();

}
void smallPil(float h)
{

    glBindTexture(GL_TEXTURE_2D,textureWall);
    wall(h);

    glPushMatrix();
    glTranslatef(40.0f,0,0);
    wall(h);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(50.0f,h,0);
    glRotatef(90,0,0,1);
    wall(50.0f);
    glPopMatrix();


    //bottom
    glPushMatrix();
    glTranslatef(60.0f,0.0f,0);
    glRotatef(90,0,0,1);
    wall(70.0f);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(60.0f,0.0f,10.0f);
    glRotatef(90,0,0,1);
    wall(70.0f);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(50.0f,0.0f,-10.0f);
    glRotatef(90,1,0,0);
    wall(20.0f);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-10.0f,0.0f,-10.0f);
    glRotatef(90,1,0,0);
    wall(20.0f);
    glPopMatrix();

float j=15.0;
glBindTexture(GL_TEXTURE_2D,textureStick);
    for(int i=0;i<5;i++){
    glPushMatrix();
        glTranslatef(j,0,-5);
        glRotatef(-90,1,0,0);
        gluCylinder(quad,0.5,0.5,h,20,20);
    glPopMatrix();
    j+=5;
    }
}
void drawWall(int w,int h){

        glBegin(GL_QUADS);
        glTexCoord2f(0,0);glVertex3f(0,0,0);
        glTexCoord2f(1,0);glVertex3f(w,0,0);
        glTexCoord2f(1,1);glVertex3f(w,h,0);
        glTexCoord2f(0,1);glVertex3f(0,h,0);
        glEnd();
}


void staircase(){

    glBindTexture(GL_TEXTURE_2D,textureBrick);
    glPushMatrix();
    glTranslatef(195,6,5);
    for(float j=-250.0;j<250.0;j+=256)
    for(float i=-250.0;i<250.0;i+=256){
    glBegin(GL_QUADS);
		glTexCoord2f(0,0);glVertex3f(i, 0.0f, j);
		glTexCoord2f(1,0);glVertex3f(i+256, 0.0f,  j);
		glTexCoord2f(1,1);glVertex3f( i+256, 0.0f,  j+256);
		glTexCoord2f(0,1);glVertex3f( i, 0.0f, j+256);
	glEnd();
    }
    glPopMatrix();
    glBindTexture(GL_TEXTURE_2D,textureStaircase);
    glPushMatrix();
    glTranslatef(200,-260,0);
    glutSolidCube(530);
    glPopMatrix();

}
void arrangeMuseumImages(){
      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[0]);
      glPushMatrix();
            glTranslatef(-1396,55,570);
            glRotatef(90,0,1,0);
            drawWall(60,60);
      glPopMatrix();


      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[1]);
      glPushMatrix();
            glTranslatef(-1396,100,485);
            glRotatef(90,0,1,0);
            drawWall(60,60);
      glPopMatrix();

      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[2]);
      glPushMatrix();
            glTranslatef(-1396,60,400);
            glRotatef(90,0,1,0);
            drawWall(60,60);
      glPopMatrix();

      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[3]);
      glPushMatrix();
            glTranslatef(-1396,100,310);
            glRotatef(90,0,1,0);
            drawWall(60,60);
      glPopMatrix();

      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[4]);
      glPushMatrix();
            glTranslatef(-1396,65,220);
            glRotatef(90,0,1,0);
            drawWall(60,60);
      glPopMatrix();

      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[5]);
      glPushMatrix();
            glTranslatef(-1396,100,130);
            glRotatef(90,0,1,0);
            drawWall(60,60);
      glPopMatrix();

      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[6]);
      glPushMatrix();
            glTranslatef(-1396,70,40);
            glRotatef(90,0,1,0);
            drawWall(60,60);
      glPopMatrix();
      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[7]);
      glPushMatrix();
            glTranslatef(-1130,60,598);

            drawWall(50,50);
      glPopMatrix();

      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[8]);
      glPushMatrix();
            glTranslatef(-1200,100,598);
            drawWall(50,50);
      glPopMatrix();

      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[9]);
      glPushMatrix();
            glTranslatef(-1270,60,598);
            drawWall(50,50);
      glPopMatrix();

      glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[10]);
      glPushMatrix();
            glTranslatef(-1340,100,598);
            drawWall(50,50);
      glPopMatrix();

       glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[12]);
       glPushMatrix();
            glTranslatef(-1380,70,-97);
            drawWall(50,50);
        glPopMatrix();

       glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[11]);
       glPushMatrix();
            glTranslatef(-1300,100,-97);
            drawWall(50,50);
        glPopMatrix();

        glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[13]);
       glPushMatrix();
            glTranslatef(-1220,70,-97);
            drawWall(50,50);
        glPopMatrix();

       glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[14]);
       glPushMatrix();
            glTranslatef(-1145,100,-97);
            drawWall(50,55);
        glPopMatrix();

        glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[16]);
        glPushMatrix();
            glTranslatef(-1052,100,580);
            glRotatef(90,0,1,0);
            drawWall(50,50);
        glPopMatrix();

        glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[17]);
        glPushMatrix();
            glTranslatef(-1052,60,510);
            glRotatef(90,0,1,0);
            drawWall(50,50);
        glPopMatrix();


         glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[18]);
        glPushMatrix();
            glTranslatef(-1052,100,440);
            glRotatef(90,0,1,0);
            drawWall(50,50);
        glPopMatrix();


        glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[20]);
        glPushMatrix();
            glTranslatef(-1052,60,370);
            glRotatef(90,0,1,0);
            drawWall(50,50);
        glPopMatrix();


        glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[19]);
        glPushMatrix();
            glTranslatef(-1052,100,300);
            glRotatef(90,0,1,0);
            drawWall(50,50);
        glPopMatrix();




        glBindTexture(GL_TEXTURE_2D,textureMeuseumImage[15]);
        glPushMatrix();
            glTranslatef(-1052,66,-12);
            glRotatef(90,0,1,0);
            drawWall(50,50);
        glPopMatrix();

}
void cloud(int r){
    int d=r+r*.75;
    glBindTexture(GL_TEXTURE_2D,textureWall);
    glPushMatrix();
        glRotatef(cloudS,1,1,1);
            glPushMatrix();
                    glTranslatef(0,10+d,0);
                    glutSolidSphere(r,15,15);
                glPopMatrix();
                glPushMatrix();
                    glTranslatef(0,20+d,0);
                    glutSolidSphere(r,15,15);
                glPopMatrix();

                glPushMatrix();
                    glTranslatef(0,35+d,20);
                    glutSolidSphere(r*1.1,15,15);
                glPopMatrix();

                glPushMatrix();
                    glTranslatef(-30-d,40+d,0);
                    glutSolidSphere(r*.9,15,15);
                glPopMatrix();

                glPushMatrix();
                    glTranslatef(-10-d,10+d,0);
                    glutSolidSphere(r*1.2,15,15);
                glPopMatrix();
                glPushMatrix();
                    glTranslatef(-30-d,20+d,0);
                    glutSolidSphere(r*.8,15,15);
                glPopMatrix();

                glPushMatrix();
                    glTranslatef(-40-d,35+d,20);
                    glutSolidSphere(r*1.15,15,15);
                glPopMatrix();

                glPushMatrix();
                    glTranslatef(-50-d,50+d,0);
                    glutSolidSphere(r*.95,15,15);
                glPopMatrix();


        glPopMatrix();
}

void allCloud(){
 //////////////////////cloud using sphere ////////////////
    cloudS+=0.003;
    glPushMatrix();
        glRotatef(cloudS,0,1,0);
        glTranslatef(500,400,-900);
        cloud(38);
    glPopMatrix();
    glPushMatrix();
        glRotatef(cloudS*1.2,0,1,0);
        glTranslatef(700,680,-750);
        cloud(55);
    glPopMatrix();
    glPushMatrix();
        glRotatef(-cloudS*.8,0,1,0);
        glTranslatef(-600,650,-790);
        cloud(60);
    glPopMatrix();
    glPushMatrix();
        glRotatef(cloudS*0.7,0,1,0);
        glTranslatef(400,800,-760);
        cloud(80);
    glPopMatrix();
    glPushMatrix();
        glRotatef(-cloudS*1.1,0,1,0);
        glTranslatef(0,540,-810);
        cloud(70);
    glPopMatrix();
    glPushMatrix();
        glRotatef(cloudS*.9,0,1,0);
        glTranslatef(-200,750,-777);
        cloud(45);
    glPopMatrix();


}

void tree(){
     glBindTexture(GL_TEXTURE_2D,textureTree);
    glPushMatrix();
        glTranslatef(205,120,400);
        glRotatef(90,1,0,0);
        gluSphere(quad,40,7,7);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(205,120,350);
        glRotatef(90,1,0,0);
        gluSphere(quad,40,7,7);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(145,120,400);
        glRotatef(90,1,0,0);
        gluSphere(quad,40,7,7);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(145,120,350);glRotatef(90,1,0,0);
        gluSphere(quad,40,7,7);
    glPopMatrix();
        glPushMatrix();
        glTranslatef(180,165,375);glRotatef(90,1,0,0);
        gluSphere(quad,40,7,7);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureTreeBody);
    glPushMatrix();

        glTranslatef(180,0,375);
        glRotatef(-90,1,0,0);
        gluCylinder(quad,15,15,120,8,8);
    glPopMatrix();
}
void allTree(){

    glPushMatrix();
        glTranslatef(-500,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-225,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(150,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(500,0,125-1100);
        tree();
    glPopMatrix();


    glPushMatrix();
        glTranslatef(150,0,-500);

    glPushMatrix();
        glTranslatef(-500,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-225,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(150,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(500,0,125-1100);
        tree();
    glPopMatrix();
    glPopMatrix();


    glPushMatrix();
        glTranslatef(1600,0,-500);
        glRotatef(90,0,1,0);
    glPushMatrix();
        glTranslatef(-500,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-225,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(150,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(500,0,125-1100);
        tree();
    glPopMatrix();
    glPopMatrix();



    glPushMatrix();
        glTranslatef(-100,0,-600);
        glRotatef(90,0,1,0);
    glPushMatrix();
        glTranslatef(-500,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-225,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(150,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(500,0,125-1100);
        tree();
    glPopMatrix();
    glPopMatrix();


    glPushMatrix();
        glTranslatef(-500,0,-600);
        glRotatef(90,0,1,0);
    glPushMatrix();
        glTranslatef(-500,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-225,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(150,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(500,0,125-1100);
        tree();
    glPopMatrix();
    glPopMatrix();


    glPushMatrix();
        glTranslatef(-500,0,1400);
        glRotatef(90,0,1,0);
    glPushMatrix();
        glTranslatef(-225,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(150,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(500,0,125-1100);
        tree();
    glPopMatrix();
    glPopMatrix();


    // infront of shaheed minar

    int j=0;
/*    for(int i=0;i<10;i++){
    j+=200;
    glPushMatrix();
        glTranslatef(-500+j,0,1700);
        glRotatef(90,0,1,0);
    //glPushMatrix();
      //  glTranslatef(-225,0,125-1100);
        //tree();
    //glPopMatrix();

    glPushMatrix();
        glTranslatef(150,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(500,0,125-1100);
        tree();
    glPopMatrix();
    glPopMatrix();
}
*/
//right side of shiheed minar
j=0;
for(int i=0;i<10;i++){
    j+=200;
    glPushMatrix();
        glTranslatef(2000-j/10,0,1700-j);
        glRotatef(90,0,1,0);
    //glPushMatrix();
      //  glTranslatef(-225,0,125-1100);
        //tree();
    //glPopMatrix();

    glPushMatrix();
        glTranslatef(150,0,125-1100);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(500,0,125-1100);
        tree();
    glPopMatrix();
    glPopMatrix();
}

}
void drawFlowers(){

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-200,27,28);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-200,27,60);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-200,27,85);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-200,27,110);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();



    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-163,27,15);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-163,27,50);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-163,27,75);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-163,27,100);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-163,27,120);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-125,27,-10);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-125,27,34);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-125,27,60);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-125,27,85);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-125,27,115);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-89,27,-30);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-89,27,15);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-89,27,38);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-89,27,65);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-89,27,90);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-89,27,120);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    //

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-50,27,-30);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-50,27,15);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-50,27,38);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-50,27,65);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-50,27,90);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-50,27,120);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    //

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-12,27,-30);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-12,27,15);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-12,27,38);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-12,27,65);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(-12,27,90);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(-12,27,120);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();



    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(26,27,-30);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(26,27,15);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(26,27,38);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(26,27,65);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(26,27,90);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(26,27,120);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();
    //

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(65,27,-30);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(65,27,15);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(65,27,38);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(65,27,65);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(65,27,90);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(65,27,120);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    //

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(103,27,-30);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(103,27,15);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(103,27,38);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(103,27,65);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(103,27,90);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(103,27,120);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    //

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(140,27,-10);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(140,27,5);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(140,27,28);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(140,27,55);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(140,27,80);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(140,27,120);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();
    //

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(179,27,10);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(179,27,25);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(179,27,50);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(179,27,75);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(179,27,100);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(179,27,120);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();
    //


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(218,27,33);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(218,27,48);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(218,27,65);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(218,27,80);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureFlower[1]);
    glPushMatrix();
    glTranslatef(218,27,105);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D,textureFlower[0]);
    glPushMatrix();
    glTranslatef(218,27,125);
    glRotatef(-80,1,0,0);
    gluDisk(quad,0,19,20,1);
    glPopMatrix();

}
void drawBoard(){

    // NAME ID Billboard
    glPushMatrix();
    glTranslatef(520,50,300);
    glRotatef(-45,0,1,0);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,textureIntro);
    drawWall(50,50);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0,1,-2);
    glBindTexture(GL_TEXTURE_2D,textureWall);
    drawWall(49,49);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(25,5,0);
    glRotatef(90,1,0,0);
    glBindTexture(GL_TEXTURE_2D,textureStick);
    gluCylinder(quad,3,3,50,8,8);
    glPopMatrix();
    glPopMatrix();

    // Museum  Billboard
    glPushMatrix();
    glTranslatef(-740,50,330);
    glRotatef(90,0,1,0);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,textureMusuem);
    drawWall(50,50);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0,1,-2);
    glBindTexture(GL_TEXTURE_2D,textureWall);
    drawWall(49,49);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(25,5,0);
    glRotatef(90,1,0,0);
    glBindTexture(GL_TEXTURE_2D,textureStick);
    gluCylinder(quad,3,3,50,8,8);
    glPopMatrix();
    glPopMatrix();

}

void renderScene(void) {

	if (deltaMove)
		computePos(deltaMove);
	if (deltaAngle)
		computeDir(deltaAngle);
    if(upDown)
        computeUp(upDown);
	if(Vangle)
        computeUPangle(Vangle);
	// Clear Color and Depth Buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Reset transformations
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	// Set the camera
	gluLookAt(	x, y+upangle, z,
				x+lx, y,  z+lz,
				0.0f, 1.0f,  0.0f);

// Draw ground
 quad = gluNewQuadric();
        gluQuadricNormals(quad,GLU_SMOOTH);
        gluQuadricTexture(quad, GLU_TRUE);
        gluQuadricTexture(quad, 100);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, textureGrass);


    for(float j=-1600.0;j<1600.0;j+=256)
    for(float i=-1600.0;i<1600.0;i+=256){
    glBegin(GL_QUADS);
		glTexCoord2f(0,0);glVertex3f(i, 0.0f, j);
		glTexCoord2f(1,0);glVertex3f(i+256, 0.0f,  j);
		glTexCoord2f(1,1);glVertex3f( i+256, 0.0f,  j+256);
		glTexCoord2f(0,1);glVertex3f( i, 0.0f, j+256);
	glEnd();
    }


    glBindTexture(GL_TEXTURE_2D,textureSky);

    glPushMatrix();
    glutSolidSphere(2000,200,200);
    glPopMatrix();

glPushMatrix();
    glTranslatef(-17,24.0,0);

    //left columns
    glPushMatrix();
    glRotatef(30,0,1,0);
    glPushMatrix();
    smallPil(140.0f);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(90,0,0);
    smallPil(200.0f);
    glPopMatrix();
    glPopMatrix();

    //right columns
    glPushMatrix();
    glRotatef(-30,0,1,0);
    glTranslatef(250,0,-220);
    glPushMatrix();
    glTranslatef(90,0,0);
    smallPil(140.0f);
    glPopMatrix();
    glPushMatrix();
    smallPil(200.0f);
    glPopMatrix();
    glPopMatrix();

//MIDDLE
    glPushMatrix();
    glTranslatef(170,0,-60);
    wall(230.0f);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(220,0,-60);
    wall(230.0f);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(270,0,-60);
    wall(230.0f);
    glPopMatrix();

            //middle sticks
            float j=185.0;
            glBindTexture(GL_TEXTURE_2D,textureStick);
            for(int i=0;i<7;i++){
            glPushMatrix();
                glTranslatef(j,0,-60);
                glRotatef(-90,1,0,0);
                gluCylinder(quad,0.5,0.5,230.0,20,20);
            glPopMatrix();
            j+=5;
            }
            j=235.0;
            glBindTexture(GL_TEXTURE_2D,textureStick);
            for(int i=0;i<7;i++){
            glPushMatrix();
            glTranslatef(j,0,-60);
            glRotatef(-90,1,0,0);
            gluCylinder(quad,0.5,0.5,230.0,20,20);
            glPopMatrix();
            j+=5;
            }

    //middle bottom
    glPushMatrix();
    glTranslatef(160,10,-60);
    glRotatef(-90,0,0,1);
    wall(130.0f);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(160,10,-50);
    glRotatef(-90,0,0,1);
    wall(130.0f);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(160,10,-70);
    glRotatef(-90,0,0,1);
    wall(130.0f);
    glPopMatrix();



    //middle top
    glPushMatrix();
        glPushMatrix();
        glTranslatef(170,225,-60);
        glRotatef(45,1,0,0);
        wall(90.0f);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(220,225,-60);
        glRotatef(45,1,0,0);
        wall(90.0f);
        glPopMatrix();
        glPushMatrix();
        glTranslatef(270,225,-60);
        glRotatef(45,1,0,0);
        wall(90.0f);
        glPopMatrix();

        glPushMatrix();
            glTranslatef(170.0f,295.0f,00.0);
            //glRotatef(45,1,0,0);
            glRotatef(-90,0,0,1);
            wall(100.0f);
        glPopMatrix();
    glPopMatrix();

        //middle top sticks

            j=185.0;
            glBindTexture(GL_TEXTURE_2D,textureStick);
            for(int i=0;i<7;i++){
            glPushMatrix();
                glTranslatef(j,230.0,-65);
                glRotatef(-45,1,0,0);
                gluCylinder(quad,0.5,0.5,80.0,20,20);
            glPopMatrix();
            j+=5;
            }
            j=235.0;
            glBindTexture(GL_TEXTURE_2D,textureStick);
            for(int i=0;i<7;i++){
            glPushMatrix();
            glTranslatef(j,230.0,-65);
            glRotatef(-45,1,0,0);
            gluCylinder(quad,0.5,0.5,80.0,20,20);
            glPopMatrix();
            j+=5;
            }


            //middle horizontal stick
            glPushMatrix();
            glTranslatef(j,230.0,-60);
            glRotatef(-90,0,1,0);
            gluCylinder(quad,0.5,0.5,100.0,20,20);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(j,260.0,-30);
            glRotatef(-90,0,1,0);
            gluCylinder(quad,0.5,0.5,100.0,20,20);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(j,76.0,-65);
            glRotatef(-90,0,1,0);
            gluCylinder(quad,0.5,0.5,100.0,20,20);
            glPopMatrix();
            glPushMatrix();
            glTranslatef(j,152.0,-65);
            glRotatef(-90,0,1,0);
            gluCylinder(quad,0.5,0.5,100.0,20,20);
            glPopMatrix();



    //circle
    glBindTexture(GL_TEXTURE_2D,textureRed);
    glPushMatrix();
    glTranslatef(225,170,-85);
        glBegin(GL_POLYGON);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/50 ;
		float r=85;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();

glPopMatrix();



    //stage stare
    glPushMatrix();
        glTranslatef(0,2,0);
        staircase();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0,10,-20);
        staircase();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0,18,-40);
        staircase();
    glPopMatrix();


    glBindTexture(GL_TEXTURE_2D,textureBrick);
    glPushMatrix();
    glTranslatef(200,1,0);

    for(float j=-500.0;j<500.0;j+=256)
    for(float i=-500.0;i<500.0;i+=256){
    glBegin(GL_QUADS);
		glTexCoord2f(0,0);glVertex3f(i, 2.0f, j);
		glTexCoord2f(1,0);glVertex3f(i+256, 2.0f,  j);
		glTexCoord2f(1,1);glVertex3f( i+256, 2.0f,  j+256);
		glTexCoord2f(0,1);glVertex3f( i, 2.0f, j+256);
	glEnd();
    }
    glBindTexture(GL_TEXTURE_2D,textureWall1);


    glPushMatrix();
        //outside wall
        glPushMatrix();
            glTranslatef(-1405,0,600);
            glRotatef(90,0,1,0);
            drawWall(700,180);
        glPopMatrix();


        glPushMatrix();
            glTranslatef(-1400,0,602);
            //glRotatef(0,0,1,0);
            drawWall(350,180);
        glPopMatrix();


        glPushMatrix();
            glTranslatef(-1400,0,-103);
            //glRotatef(0,0,1,0);
            drawWall(350,180);
        glPopMatrix();


        //front side
        glPushMatrix();
            glTranslatef(-1400+352,0,600);
            glRotatef(90,0,1,0);
            drawWall(390,180);
        glPopMatrix();

        glPushMatrix();
            glTranslatef(-1400+352,0,28);
            glRotatef(90,0,1,0);
            drawWall(130,180);
        glPopMatrix();



         //inside wall
        glBindTexture(GL_TEXTURE_2D,textureInsideWall);
        glPushMatrix();
            glTranslatef(-1400,0,600);
            glRotatef(90,0,1,0);
            drawWall(700,180);
        glPopMatrix();


        glPushMatrix();
            glTranslatef(-1401,0,600);
            //glRotatef(0,0,1,0);
            drawWall(350,180);
        glPopMatrix();


        glPushMatrix();
            glTranslatef(-1400,0,-100);
            //glRotatef(0,0,1,0);
            drawWall(350,180);
        glPopMatrix();


       //inside wall front side

        glPushMatrix();
            glTranslatef(-1400+350,0,602);
            glRotatef(90,0,1,0);
            drawWall(394,180);
        glPopMatrix();



        glPushMatrix();
            glTranslatef(-1400+350,0,30);
            glRotatef(90,0,1,0);
            drawWall(130,180);
        glPopMatrix();




    //floor
        glBindTexture(GL_TEXTURE_2D,textureFloor);
        glPushMatrix();
            glTranslatef(-1400,3,600);
            glRotatef(90,0,1,0);
           glPushMatrix();
            glRotatef(90,1,0,0);
            drawWall(700,350);
        glPopMatrix();
        glPopMatrix();

        glBindTexture(GL_TEXTURE_2D,textureCeiling);


        //celling
        glPushMatrix();
            glTranslatef(-1400,180,600);
            glRotatef(90,0,1,0);
        glPushMatrix();
            glRotatef(90,1,0,0);
            drawWall(700,350);
        glPopMatrix();
        glPopMatrix();

        glBindTexture(GL_TEXTURE_2D,textureCeiling2);

        //roof
        glPushMatrix();
            glTranslatef(-1400,183,600);
            glRotatef(90,0,1,0);
        glPushMatrix();
            glRotatef(90,1,0,0);
            drawWall(700,350);
        glPopMatrix();
        glPopMatrix();

        arrangeMuseumImages();

    glPopMatrix();

    drawFlowers();
    glPopMatrix();

    allTree();
    allCloud();
    drawBoard();


	glutSwapBuffers();
}


void pressKey(int key, int xx, int yy) {

	switch (key) {
		case GLUT_KEY_LEFT : deltaAngle = -0.004f; break;
		case GLUT_KEY_RIGHT : deltaAngle = 0.004f; break;
		case GLUT_KEY_UP : deltaMove = 10.0f; break;
		case GLUT_KEY_DOWN : deltaMove = -10.0f; break;
	}
}

void releaseKey(int key, int x, int y) {

	switch (key) {
		case GLUT_KEY_LEFT :
		case GLUT_KEY_RIGHT : deltaAngle = 0.0f;break;
		case GLUT_KEY_UP :
		case GLUT_KEY_DOWN : deltaMove = 0.0f;break;
	}
}

/*void update(int v){
    //renderScene();
    glutPostRedisplay();
glutTimerFunc(25,update,0);
}
*/
void keyboard(unsigned char key, int x, int y) {
   switch (key) {
      case 'w':upDown=10.0; break;
      case 's':  upDown=-10.0; break;
      case 'q':Vangle=0.001; break;
      case 'a':Vangle=-0.001; break;
      case 27:exit(0);break;
   }
}
void keyboardUp(unsigned char key, int x, int y) {
   switch (key) {
      case 'w':upDown=0.0f; break;
      case 's':upDown=0.0f; break;
      case 'q':Vangle=0.0; break;
      case 'a':Vangle=0.0; break;

   }
}



int main(int argc, char **argv) {


	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100,20);
	glutInitWindowSize(1200,700);
	glutCreateWindow("Shaheed Minar");
    glutFullScreen();
	glutDisplayFunc(renderScene);
	glutReshapeFunc(changeSize);
	glutIdleFunc(renderScene);

	glutSpecialFunc(pressKey);
    func();
	glutIgnoreKeyRepeat(1);
	glutSpecialUpFunc(releaseKey);
    glutKeyboardFunc(keyboard);
    glutKeyboardUpFunc(keyboardUp);

	glEnable(GL_DEPTH_TEST);
    //sndPlaySound("b.wav",SND_ASYNC|SND_LOOP);

	glutMainLoop();

	return 1;
}
